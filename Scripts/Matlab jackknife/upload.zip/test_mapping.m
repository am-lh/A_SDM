clear; close all
original=[-10:1:16]';
LowerBound.x1 = 3;
UpperBound.x1 = 6;
ParaName = {'x1'};
new = mapping_parameters(original,LowerBound,UpperBound,ParaName);